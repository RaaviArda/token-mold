export class TMController {
	constructor() {
		console.log("yay!");
		console.log("yay2!")
	}

}